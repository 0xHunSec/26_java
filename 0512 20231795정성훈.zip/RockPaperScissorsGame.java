package day10;

import java.util.*;

abstract class Player { // 추상 클래스
    protected String[] shape = {"가위", "바위", "보"};
    private String name;

    public Player(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    // 선수가 가위바위보 중 하나를 리턴
    public abstract String turn();
}

class MachinePlayer extends Player {
    private Random random = new Random();

    public MachinePlayer(String name) {
        super(name);
    }

    @Override
    public String turn() {
        int index = random.nextInt(3);
        return shape[index];
    }
}

class HumanPlayer extends Player {
    private Scanner scanner = new Scanner(System.in);

    public HumanPlayer(String name) {
        super(name);
    }

    @Override
    public String turn() {
        while (true) {
            System.out.print(getName() + " 입력 [가위/바위/보] >> ");
            String input = scanner.nextLine();

            if (input.equals("가위") || input.equals("바위") || input.equals("보")) {
                return input;
            }

            System.out.println("잘못 입력했습니다.");
        }
    }
}

public class RockPaperScissorsGame {
    public static void main(String[] args) {
        Player human = new HumanPlayer("사용자");
        Player machine = new MachinePlayer("컴퓨터");

        String h = human.turn();
        String m = machine.turn();

        System.out.println(human.getName() + " : " + h);
        System.out.println(machine.getName() + " : " + m);

        if (h.equals(m)) {
            System.out.println("비겼습니다.");
        } else if (
            h.equals("가위") && m.equals("보") ||
            h.equals("바위") && m.equals("가위") ||
            h.equals("보") && m.equals("바위")
        ) {
            System.out.println("사용자 승리!");
        } else {
            System.out.println("컴퓨터 승리!");
        }
    }
}