class CCTV {
    private String resolution;

    public CCTV(String resolution) {
        this.resolution = resolution;
    }

    protected String getResolution() {
        return resolution;
    }
}

public class AICCTV extends CCTV {
    private boolean faceRecognition;

    public AICCTV(String resolution, boolean faceRecognition) {
        super(resolution);
        this.faceRecognition = faceRecognition;
    }

    public void printInfo() {
        System.out.println("CCTV는 " + getResolution() + "급이며, 현재 얼굴인식 "
                + (faceRecognition ? "작동 중" : "작동 중지"));
    }

    public static void main(String[] args) {
        AICCTV ai = new AICCTV("FHD", true);
        ai.printInfo();
    }
}