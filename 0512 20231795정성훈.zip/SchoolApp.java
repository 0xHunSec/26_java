class Person {
    String name;
    String phone;

    public Person(String name, String phone) {
        this.name = name;
        this.phone = phone;
    }
}

class Student extends Person {
    public Student(String name, String phone) {
        super(name, phone);
    }
}

class Research extends Person {
    public Research(String name, String phone) {
        super(name, phone);
    }
}

public class SchoolApp {
    public static void print(Person p) {
        if (p instanceof Student) {
            System.out.println("학생 객체입니다.");
        }
        else if (p instanceof Research) {
            System.out.println("리서처 객체입니다.");
        }
        else {
            System.out.println("사람 객체입니다.");
        }
    }

    public static void main(String[] args) {
        Person p = new Person("이사람", "0110");
        Person p1 = new Student("김학생", "1111");
        Person p2 = new Research("박리서처", "2222");

        print(p);
        print(p1);
        print(p2);
    }
}