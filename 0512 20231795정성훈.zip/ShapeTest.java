import java.util.ArrayList;

class Shape {
}

class Line extends Shape {
}

class Circle extends Shape {
}

public class ShapeTest {
    public static void main(String[] args) {

        Shape s = new Line();
        Shape s1 = new Circle();

        ArrayList<Shape> array = new ArrayList<Shape>();
        array.add(s);
        array.add(s1);
        array.add(new Line());

        for (Shape shape : array) {
            if (shape instanceof Line) {
                System.out.println("선객체");
            }

            if (shape instanceof Circle) {
                System.out.println("원객체");
            }
        }
    }
}