package day05;

import java.util.Scanner;

public class Add {

	public static void main(String[] args) {
		// 2개의 정수를 입력받아서 더한 결과를 출력하시오
		
		// 입력을 받기 위한 Scanner 객체 생성
		Scanner scanner = new Scanner(System.in);
		
		// 첫 번째 정수 입력
		System.out.print("첫 번째 정수를 입력하세요: ");
		int num1 = scanner.nextInt();
		
		// 두 번째 정수 입력
		System.out.print("두 번째 정수를 입력하세요: ");
		int num2 = scanner.nextInt();
		
		// 두 정수 더하기
		int sum = num1 + num2;
		
		// 결과 출력
		System.out.println("두 수의 합은 " + sum + " 입니다.");
		
		// Scanner 자원 해제
		scanner.close();
	}

}