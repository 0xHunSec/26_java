package day05;

import java.util.Scanner;

public class Overloading {

	static Scanner sc = new Scanner(System.in);

	// 1. 고객 정보 확인하기 (매개변수로 받음)
	public static void menuGuestInfo(String userName, String userMobile) {
		System.out.println("=== 현재 고객 정보 ===");
		System.out.println("이름   : " + userName);
		System.out.println("연락처 : " + userMobile);
	}

	// 2. 장바구니 상품 목록 보기
	public static void menuCartItemList() {
		System.out.println("=== 장바구니 상품 목록 ===");
		System.out.println("1. 아메리카노 x 2");
		System.out.println("2. 카페라떼   x 1");
	}

	// 3. 장바구니 비우기
	public static void menuCartClear() {
		System.out.println("장바구니를 비웠습니다.");
	}

	// 4. 장바구니에 항목 추가하기
	public static void menuCartAddItem() {
		System.out.print("추가할 상품명 : ");
		String name = sc.next();
		System.out.print("수량 : ");
		int count = sc.nextInt();
		System.out.println(name + " " + count + "개를 담았습니다.");
	}

	// 5. 장바구니의 항목 수량 줄이기
	public static void menuCartRemoveItemCount() {
		System.out.print("수량을 줄일 상품명 : ");
		String name = sc.next();
		System.out.print("줄일 수량 : ");
		int count = sc.nextInt();
		System.out.println(name + " 수량을 " + count + "개 줄였습니다.");
	}

	// 6. 장바구니의 항목 삭제하기
	public static void menuCartRemoveItem() {
		System.out.print("삭제할 상품명 : ");
		String name = sc.next();
		System.out.println(name + "을(를) 삭제했습니다.");
	}

	// 7. 영수증 표시하기
	public static void menuCartBill() {
		System.out.println("======= 영수증 =======");
		System.out.println("아메리카노 x 2   9,000원");
		System.out.println("카페라떼   x 1   5,500원");
		System.out.println("---------------------");
		System.out.println("합계           14,500원");
	}

	// 8. 종료
	public static void menuExit() {
		System.out.println("프로그램을 종료합니다.");
	}

	public static void main(String[] args) {
		// 고객 정보 (main에 변수로 보관)
		String userName = "정성훈";
		String userMobile = "010-1234-5678";

		while (true) {
			System.out.println();
			System.out.println("===== 메뉴 =====");
			System.out.println("1. 고객 정보 확인");
			System.out.println("2. 장바구니 목록");
			System.out.println("3. 장바구니 비우기");
			System.out.println("4. 항목 추가");
			System.out.println("5. 항목 수량 줄이기");
			System.out.println("6. 항목 삭제");
			System.out.println("7. 영수증");
			System.out.println("8. 종료");
			System.out.print("선택 : ");
			int n = sc.nextInt();

			// 입력값 범위 검증
			if (n < 1 || n > 8) {
				System.out.println("1부터 8까지의 숫자를 입력하세요.");
			} else {
				switch (n) {
					case 1:
						// 고객 정보 출력 메소드 호출 (매개변수 전달)
						menuGuestInfo(userName, userMobile);
						break;
					case 2:
						menuCartItemList();
						break;
					case 3:
						menuCartClear();
						break;
					case 4:
						menuCartAddItem();
						break;
					case 5:
						menuCartRemoveItemCount();
						break;
					case 6:
						menuCartRemoveItem();
						break;
					case 7:
						menuCartBill();
						break;
					case 8:
						menuExit();
						return;
				}
			}
		}
	}
}