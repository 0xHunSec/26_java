package day05;

import java.util.Scanner;

public class Method02 {

	// 2개의 정수 중 최대값을 반환하는 메소드
	public static int max(int a, int b) {
		if (a > b) {
			return a;
		} else {
			return b;
		}
		// 한 줄로 쓰면: return (a > b) ? a : b;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.print("정수 1 : ");
		int a = sc.nextInt();

		System.out.print("정수 2 : ");
		int b = sc.nextInt();

		int result = max(a, b);
		System.out.println("최대값 : " + result);
	}
}