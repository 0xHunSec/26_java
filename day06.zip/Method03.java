package day05;

import java.util.Scanner;

public class Method03 {

	// 덧셈
	public static int add(int a, int b) {
		return a + b;
	}

	// 뺄셈
	public static int sub(int a, int b) {
		return a - b;
	}

	// 곱셈
	public static int mul(int a, int b) {
		return a * b;
	}

	// 나눗셈 (0으로 나누기 방지)
	public static int div(int a, int b) {
		if (b == 0) {
			System.out.println("0으로 나눌 수 없습니다.");
			return 0;
		}
		return a / b;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.print("정수 1 : ");
		int a = sc.nextInt();

		System.out.print("정수 2 : ");
		int b = sc.nextInt();

		System.out.print("연산 부호를 입력: ");
		String s = sc.next();

		switch (s) {
			case "+":
				System.out.println(a + " + " + b + " = " + add(a, b));
				break;
			case "-":
				System.out.println(a + " - " + b + " = " + sub(a, b));
				break;
			case "*":
				System.out.println(a + " * " + b + " = " + mul(a, b));
				break;
			case "/":
				System.out.println(a + " / " + b + " = " + div(a, b));
				break;
			default:
				System.out.println("잘못된 연산 부호입니다.");
				break;
		}
	}
}