package day05;

import java.util.Scanner;

public class Method01 {

	// 1. 매개변수도 없고, 반환형도 없는 add() 메소드
	public static void add() {
		Scanner scan = new Scanner(System.in);
		int num = scan.nextInt();
		int num2 = scan.nextInt();
		System.out.println(num + num2);
	}

	// 2. 매개변수는 있고, 반환형은 없는 add() 메소드
	public static void add(int a, int b) {
		System.out.println(a + b);
	}

	// 3. 매개변수는 없고, 반환형은 있는 add() 메소드
	public static int add2() {
		Scanner scan = new Scanner(System.in);
		int num = scan.nextInt();
		int num2 = scan.nextInt();
		return num + num2;
	}

	// 4. 매개변수도 있고, 반환형도 있는 add() 메소드
	public static int add(int a, int b, int c) {
		return a + b + c;
	}

	public static void main(String[] args) {
		// 1번 호출: 입력받아서 내부에서 출력
		add();

		// 2번 호출: 값 넘겨주면 내부에서 출력
		add(10, 20);

		// 3번 호출: 반환값을 받아서 출력
		int result = add2();
		System.out.println("result = " + result);

		// 4번 호출: 값 넘기고 반환값 받기
		int result2 = add(1, 2, 3);
		System.out.println("result2 = " + result2);
	}
}