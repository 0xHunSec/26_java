import java.util.Scanner;

class Book {
    String title, author;
    
    // 생성자: 제목과 저자를 받아 필드 초기화
    public Book(String title, String author) { 
        this.title = title;
        this.author = author;
    }
}

public class BookArray {
    public static void main(String[] args) {
        // 1. 크기가 2인 Book 객체 배열의 '레퍼런스(참조)' 선언 및 생성
        Book[] book = new Book[2]; 

        Scanner scanner = new Scanner(System.in);
        
        // 2. 반복문을 통해 입력받고 실제 객체 생성하여 배열에 할당
        for(int i = 0; i < book.length; i++) {
            System.out.print("제목>>");
            String title = scanner.nextLine();
            
            System.out.print("저자>>");
            String author = scanner.nextLine();
            
            book[i] = new Book(title, author); // 실제 객체 생성 및 배열 원소에 저장
        }

        // 3. 배열에 저장된 객체들의 정보 출력
        for(int i = 0; i < book.length; i++) {
            System.out.print("(" + book[i].title + ", " + book[i].author + ")");
        }

        scanner.close();
    }
}