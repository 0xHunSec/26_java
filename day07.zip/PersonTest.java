package day07;

public class PersonTest {

	public static void main(String[] args) {
		person hong = new Person();
		hong.name = "홍길동";
		hone.age = 20;
		hong.abc = 'A';
		hong.밥먹기();
		hong.운동하기("헬스");
	}
	

}
