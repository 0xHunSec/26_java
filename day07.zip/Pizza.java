package day07;

public class Pizza {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
